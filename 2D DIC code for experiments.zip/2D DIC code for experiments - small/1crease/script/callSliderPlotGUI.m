%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% This script interacts with an image and grab points based on the mouse
% click
%
% Written by: M. Gori, 2020  ~  marcello.gori@jpl.nasa.gov
%
% If using these codes for research or industrial purposes, please cite:
% Gori, M., & Bosi, F. (2022). Deployment and surface accuracy of regularly creased membranes. Extreme Mechanics Letters, 101849. 
% DOI: https://doi.org/10.1016/j.eml.2022.101849
% https://www.sciencedirect.com/science/article/pii/S2352431622001420 
% Published 27 July 2022.
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

function [brightnessThreshold] = callSliderPlotGUI(imageCropped, brightnessThresh, select)


if strcmp(select, 'user') || strcmp(select, 'default')
    brightnessThreshold = brightnessThresh;
    
else
    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    % CALL SLIDER PLOT
    sliderPlotGUI_Threshold(imageCropped);
    
    fprintf('\nPRESS ANY KEY TO CONTINUE... \n')
    
    pause
    close all
    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    % CREATE PROMPT WINDOW TO INPUT THE THRESHOLD VALUE
    prompt     = {'Threshold value'};
    name       = 'Input threshold value';
    numLines   = 1;
    defaultAns = {'80'};
    options.Resize      = 'on';
    options.WindowStyle = 'normal';
    options.Interpreter = 'tex';
    userInput = inputdlg(prompt, name, numLines, defaultAns, options);
    
    brightnessThreshold = str2double(userInput{1});
    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
end

end