%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% This script imports the csv data of interest and outputs the force value
%
% Written by: M. Gori, 2020  ~  marcello.gori@jpl.nasa.gov
%
% If using these codes for research or industrial purposes, please cite:
% Gori, M., & Bosi, F. (2022). Deployment and surface accuracy of regularly creased membranes. Extreme Mechanics Letters, 101849. 
% DOI: https://doi.org/10.1016/j.eml.2022.101849
% https://www.sciencedirect.com/science/article/pii/S2352431622001420 
% Published 27 July 2022.
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

function [time, displ, force] = csvImportData(csvFile, csvFolder, fileName)

cd(csvFolder)

% Read csv file
dataTable = readtable(csvFile);

% Find row of file of interest
indexFile = find(cellfun('length', regexp(dataTable.Filename_0, fileName)) == 1);

% Read values
time  = dataTable.Time_0(indexFile);
displ = dataTable.Displ_Instron(indexFile);
% force = dataTable.Dev1_ai1_Force(indexFile);
force = dataTable.Force_Instron(indexFile);

end

