%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% This script implements the Butterworth filter
%
% Copyright :  M. GORI, 2014
% Contact   :  marcello.gori00@gmail.com
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

function [A_filt] = filterButterworth(N, F3dB, A)

[a,b] = butter(N, F3dB);

% Butterworth filter
h  = fdesign.lowpass('N,F3dB', N, F3dB);
d1 = design(h, 'butter');

% Zero phase-shift filter
A_filt = filtfilt(d1.sosMatrix, d1.ScaleValues, double(A));

% Non-zero phase-shift filter (previously used)
% A_filt = filter(a, b, A);

return