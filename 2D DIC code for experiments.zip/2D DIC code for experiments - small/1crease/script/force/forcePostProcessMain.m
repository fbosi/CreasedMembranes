%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% This script reads an image
%
% Written by: M. Gori, 2020  ~  marcello.gori@jpl.nasa.gov
%
% If using these codes for research or industrial purposes, please cite:
% Gori, M., & Bosi, F. (2022). Deployment and surface accuracy of regularly creased membranes. Extreme Mechanics Letters, 101849. 
% DOI: https://doi.org/10.1016/j.eml.2022.101849
% https://www.sciencedirect.com/science/article/pii/S2352431622001420 
% Published 27 July 2022.
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

clc; clear; close all;


scriptsFolder = pwd;
% cd ../../2D_7cm_1crease_S1/
% cd ../../2D_7cm_1crease_S2/
cd ../../test1/
% cd ../../2D_1crease_NewT1
% cd ../../2D_1crease_NewT2


%~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
% IMPORT DATA
dataFolder = pwd;
% csvFile = '1crease.csv';
% csvFile = '2creases.csv';
 csvFile = '1creaseT1-15mm.csv';
% csvFile = '1creaseT2-15mm.csv';
% [csvFile, dataFolder] = uigetfile('*.csv', 'Select *.csv file to analyze');

% Read csv file
dataTable = readtable([dataFolder '/' csvFile]);

timeAll  = dataTable.Time_0;
forceAll = dataTable.Force_Instron;

figure;
plot(timeAll, forceAll, '.')

%~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
% Number of points to exclude at the beginning
ptsInitExclude = 9;

% Number of points to exclude from the end
ptsTailExclude = 15;

%~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
time  = timeAll(ptsInitExclude+1:end);    time = time-time(1);
force = forceAll(ptsInitExclude+1:end);   % force(1) = 0;

force = filloutliers(force, 'center', 'movmedian', 9);

% index = find(force < 0);
% force(index) = 1e-12;
%~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~


%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Call function to select gray scale via slider
cd(scriptsFolder)
% sliderPlotGUI_movmean(timeAll-timeAll(1), forceAll, ptsTailExclude);
sliderPlotGUI_smooth(time, force, ptsTailExclude);


smoothMethod = 'moving';
%~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
% CREATE PROMPT WINDOW TO INPUT THE VALUE OF THE PARAMETER

% Inspect the force vs. time plot for filtering
prompt     = {'Smoothing method'};
name       = 'Selection';
numLines   = 1;
defaultAns = {'moving'};
options.Resize      = 'on';
options.WindowStyle = 'normal';
options.Interpreter = 'tex';
userInput = inputdlg(prompt, name, numLines, defaultAns, options);

% Smoothing method
smoothMethod = userInput{1};
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%


%~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
% FILTER DATA

forceSmooth = force;
forceSmooth(1:end-ptsTailExclude) = ...
    smooth(time(1:end-ptsTailExclude), force(1:end-ptsTailExclude), smoothMethod);

forceSmooth(end-ptsTailExclude:end) = force(end-ptsTailExclude:end);

% forceSmooth = filloutliers(forceSmooth, 'center', 'movmedian', 9);
%~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~



%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Call function to select gray scale via slider
cd(scriptsFolder)
% sliderPlotGUI_movmean(timeAll-timeAll(1), forceAll, ptsTailExclude);
sliderPlotGUI_multiMovmean(time, forceSmooth, ptsTailExclude);


movmeanMultiplier = 1;
%~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
% CREATE PROMPT WINDOW TO INPUT THE VALUE OF THE PARAMETER

% Inspect the force vs. time plot for filtering
prompt     = {'Multiplier', 'Points to exclude from end of force data'};
name       = 'Selection';
numLines   = 1;
defaultAns = {'15', '3'};
options.Resize      = 'on';
options.WindowStyle = 'normal';
options.Interpreter = 'tex';
userInput = inputdlg(prompt, name, numLines, defaultAns, options);

% Stencil for movmean filter
movmeanMultiplier = str2double(userInput{1});
% Points to exclude from the end of the force data for filtering
ptsTailExcludeMovmean = str2double(userInput{2});
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%


%~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
% FILTER DATA

forceMovmean = forceSmooth;
ptsEnd = ptsTailExclude + ptsTailExcludeMovmean;

for i = 1 : movmeanMultiplier
    forceMovmean(1:end-ptsTailExclude) = ...
        movmean(forceMovmean(1:end-ptsTailExclude), 3, 'SamplePoints', time(1:end-ptsTailExclude));
end

forceMovmean(end-ptsEnd:end) = forceSmooth(end-ptsEnd:end);

% forceMovmean = filloutliers(forceMovmean, 'center', 'movmedian', 9);
%~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~



%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Call function to select gray scale via slider
cd(scriptsFolder)
sliderPlotGUI_Butterworth(time, forceMovmean, ptsTailExclude);


N    = 3;       % Order of filter
F3dB = 0.99e0;  % Cutoff frequency
%~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
% CREATE PROMPT WINDOW TO INPUT THE VALUE OF THE PARAMETER

% Inspect the force vs. time plot for filtering
prompt     = {'Select the F3dB of the Butterworth filter', 'Points to exclude at the end'};
name       = 'Select the F3dB of the Butterworth filter';
numLines   = 1;
defaultAns = {'2.5e-1', '1'};
options.Resize      = 'on';
options.WindowStyle = 'normal';
options.Interpreter = 'tex';
userInput = inputdlg(prompt, name, numLines, defaultAns, options);

% Cutoff frequency
F3dB = str2double(userInput{1});
% Points to exclude from the end of the force data for filtering
ptsTailExcludeButter = str2double(userInput{2});
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%


%~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
% FILTER DATA

forceButter = forceMovmean;
ptsEnd = ptsTailExclude + ptsTailExcludeButter;

forceButter(1:end-ptsEnd) = ...
    filterButterworth(N, F3dB, forceMovmean(1:end-ptsEnd));

% forceButter = filloutliers(forceButter, 'center', 'movmedian', 9);
%~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~



%~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
% Write force to csv file
writeDataToFile(csvFile, dataFolder, [zeros(ptsInitExclude,1); forceButter])
%~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~



%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% PLOT FORCE VS. TIME
figHandle = figure('Name', 'Force vs. Time', 'NumberTitle', 'off', 'Color', [1,1,1]);

plot(time, force, 'k.'); hold on
plot(time, forceButter, 'ro')

ax = gca;
ax.FontSize = 13;
ax.LineWidth = 2;

xlabel('time [s]');   ylabel('force [N]')
title('Filtered Force')

legend('Unfiltered', 'Filtered', 'location', 'NW')
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%



%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% PLOT FORCE VS. TIME
figHandle = figure('Name', 'Semilog Force vs. Time', 'NumberTitle', 'off', 'Color', [1,1,1]);

semilogy(time, force, 'k.'); hold on
semilogy(time, forceButter, 'ro')

ax = gca;
ax.FontSize = 13;
ax.LineWidth = 2;

xlabel('time [s]');   ylabel('semilog force [N]')
title('Filtered Force')

legend('Unfiltered', 'Filtered', 'location', 'NW')
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%



% %%
% %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% % EXPONENTIAL FIT
% 
% rng default % for reproducibility
% tdata = time;
% ydata = force;
% 
% moment = Arm .* force;
% 
% fun = @(x)sseval(x,tdata,ydata);
% x0 = rand(2,1);
% bestx = fminsearch(fun,x0);
% 
% A = bestx(1);
% lambda = bestx(2);
% yfit = A.*exp(-lambda.*tdata);
% 
% 
% % plot(tdata,ydata,'*'); hold on
% % plot(tdata,yfit,'r');
% 
% semilogy(tdata,ydata,'*'); hold on
% semilogy(tdata,yfit,'r');
% 
% xlabel('tdata')
% ylabel('Response Data and Curve')
% title('Data and Best Fitting Exponential Curve')
% legend('Data','Fitted Curve')
% hold off
% 
% function sse = sseval(x,tdata,ydata)
% 
% A = x(1);
% lambda = x(2);
% sse = sum((ydata - A*exp(-lambda*tdata)).^2);
% 
% end






