%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% This script creates a GUI slider plot to find the correct F3dB value
% for the Butterworth filter
%
% Copyright :  M. GORI, 2019
% Contact   :  marcello.gori00@gmail.com
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

function [] = sliderPlotGUI_Butterworth(x, y, ptsTailExclude)

%~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
% Assign dataObj class values
dataObj.x = x(1:end-ptsTailExclude);
dataObj.y = y(1:end-ptsTailExclude);

% Initialize data
N = 3;
dataObj.F3dB = .99e0;
%~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~


%~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
% Plot different plots according to slider location.
dataObj.fig = figure;
set(dataObj.fig, 'Name', 'GUI slider plot', 'NumberTitle', 'off', 'Color', [1,1,1]);
      
% Plot original data
plot(x, y, 'k.'); hold on
% semilogy(x, y, 'k.'); hold on

% Plot data and assign plot to update via the slider to dataObject
dataObj.plot = plot(dataObj.x, dataObj.y, 'r.');
% dataObj.plot = semilogy(dataObj.x, dataObj.y, 'r.');

ylim([-0.05 0.3])
%~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~


%~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
% Create annotation string
anString = sprintf('Butterworth : F3dB : %3.2e \n',  dataObj.F3dB);

% Write annotation on the plot
dataObj.an = annotation('textbox', [.5 .6 .3 .3], 'String', anString, 'FontSize', 12, ...
                  'Color', 'r', 'FitBoxToText', 'on', 'LineStyle', 'none', 'FontWeight', 'bold');
              
% ylim([0 max(dataObj.y) * 1.05])
              
% Create labels
title('Slide to optimal setting')
xlabel('x [px]')
ylabel('y [px]');
%~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~


%~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
% SLIDER APPEARANCE PARAMETER
dataObj.buttSlider = uicontrol('style', 'slide', ...
                 'unit', 'pix', ...
                 'position', [30 5 500 30], ...
                 'min', -1, 'max', -1e-12, 'val', -1e-12, ...
                 'sliderstep', [1/30 1/30],...
                 'callback', {@buttSlider_call, dataObj});
%~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~

end
             

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Callback for the slider
function [] = buttSlider_call(varargin)

% Call handle and data structure
[h, dataObj] = varargin{[1,3]};

% Update value
dataObj.F3dB = 10^(h.Value);

% Update filtered data
N = 3;
dataObj.y = filterButterworth(N, dataObj.F3dB, dataObj.y);

% Update the plot
set(dataObj.plot, 'ydata', dataObj.y)

% Update the string
dataObj.an.String = sprintf('Butterworth : F3dB : %3.2e', dataObj.F3dB);

% Print the value in the command window
fprintf('Butterworth : F3dB : %3.2e \n', dataObj.F3dB);

end
