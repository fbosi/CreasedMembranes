%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% This script creates a GUI slider plot to find the correct F3dB value
% for the Butterworth filter
%
% Copyright :  M. GORI, 2019
% Contact   :  marcello.gori00@gmail.com
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

function [] = sliderPlotGUI_smooth(x, y, ptsTailExclude)

%~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
% Assign dataObj class values
dataObj.x = x(1:end-ptsTailExclude);
dataObj.y = y(1:end-ptsTailExclude);

dataObj.methodNum = 1;
method = {'moving'; 'lowess'; 'loess'; 'sgolay'; 'rlowess'; 'rloess'};
%~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~


%~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
% Plot different plots according to slider location.
dataObj.fig = figure;
set(dataObj.fig, 'Name', 'GUI slider plot', 'NumberTitle', 'off', 'Color', [1,1,1]);
      
% Plot data and assign plot to update via the slider to dataObject
plot(x, y, '.'); hold on
% semilogy(x, y, '.'); hold on

% Plot data and assign plot to update via the slider to dataObject
dataObj.plot = plot(dataObj.x, dataObj.y, 'r.');
% dataObj.plot = semilogy(dataObj.x, dataObj.y, 'r.');

ylim([-0.05 0.3])
%~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~


%~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
% Create annotation string
anString = sprintf('Smooth method  :  %s', method{dataObj.methodNum});

% Write annotation on the plot
dataObj.an = annotation('textbox', [.5 .6 .3 .3], 'String', anString, 'FontSize', 12, ...
                  'Color', 'r', 'FitBoxToText', 'on', 'LineStyle', 'none', 'FontWeight', 'bold');
              
% Create labels
title('Slide to optimal setting')
xlabel('x [px]')
ylabel('y [px]');
%~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~


%~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
% SLIDER APPEARANCE PARAMETER
dataObj.slider = uicontrol('style', 'slide', ...
                 'unit', 'pix', ...
                 'position', [30 5 500 30], ...
                 'min', 1, 'max', 6, 'val', 1, ...
                 'sliderstep', [1/6 1/6],...
                 'callback', {@slider_call, dataObj});
%~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~

end
             

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Callback for the slider
function [] = slider_call(varargin)

% Call handle and data structure
[h, dataObj] = varargin{[1,3]};

% Update value
dataObj.methodNum = round(h.Value);

method = {'moving'; 'lowess'; 'loess'; 'sgolay'; 'rlowess'; 'rloess'};

% Update dark pixels (brightness < new threshold)
dataObj.y = smooth(dataObj.x, dataObj.y, method{dataObj.methodNum});

% Update the plot
set(dataObj.plot, 'ydata', dataObj.y, 'xdata', dataObj.x)

% Update the string
dataObj.an.String = sprintf('Smooth method  :  %s', method{dataObj.methodNum});

% Print the value in the command window
fprintf('Smooth method  :  %s \n', method{dataObj.methodNum});

end
