%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% This script substitute a line of a csv file
%
% Written by: M. Gori, 2020  ~  marcello.gori@jpl.nasa.gov
%
% If using these codes for research or industrial purposes, please cite:
% Gori, M., & Bosi, F. (2022). Deployment and surface accuracy of regularly creased membranes. Extreme Mechanics Letters, 101849. 
% DOI: https://doi.org/10.1016/j.eml.2022.101849
% https://www.sciencedirect.com/science/article/pii/S2352431622001420 
% Published 27 July 2022.
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

function writeDataToFile(outputFile, csvFolder, force)

cd(csvFolder)

% Read csv file
dataTable = readtable(outputFile);

% Write data to the table
dataTable.Force = force;

% Save file to output file
writetable(dataTable, outputFile);

end

