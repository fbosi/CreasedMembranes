%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% This script interacts with an image and grab points based on the mouse
% click
%
% Written by: M. Gori, 2020  ~  marcello.gori@jpl.nasa.gov
%
% If using these codes for research or industrial purposes, please cite:
% Gori, M., & Bosi, F. (2022). Deployment and surface accuracy of regularly creased membranes. Extreme Mechanics Letters, 101849. 
% DOI: https://doi.org/10.1016/j.eml.2022.101849
% https://www.sciencedirect.com/science/article/pii/S2352431622001420 
% Published 27 July 2022.
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

function [ROI_coordinates, Boundaries, Pixel2Meter] = imagePointsGrab(dataFolder, fileName, BoundIni)

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% IMPORT IMAGE DATA

% Create an object for the *.tiff image file
imageObj = Tiff([dataFolder '/' fileName], 'r');

% Import the image to a matrix. Each entry corresponds to a pixel with the
% brightness intensity - from 0 to 256 (8-bit)
imageFile = read(imageObj);

% Close the object
close(imageObj)


%~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
% Select a rectangle to crop the image
figure('Name', 'Picture Image', 'NumberTitle', 'off', 'Color', [1,1,1]);
imshow(imageFile); hold on


%~~~~~~~~~~~~~~~~~~~~~~~~
% Plot boundaries from previous plot
if isnan(BoundIni(1,1)) == 0
    plot(BoundIni(1,1), BoundIni(1,3), 'g^')
    plot(BoundIni(1,2), BoundIni(1,4), 'g^')
end

%~~~~~~~~~~~~~~~~~~~~~~~~
% Create annotation
anString = sprintf('Click on the initial and final points of the beam');
an = annotation('textbox', [.20 .45 .3 .3], 'String', anString, 'FontSize', 12, ...
    'Color', 'r', 'FitBoxToText', 'on', 'LineStyle', 'none', 'FontWeight', 'bold');

[xBoundary, yBoundary] = ginput(2);
Boundaries = [xBoundary', yBoundary'];

% Show points on the image
plot(xBoundary, yBoundary, 'r^')

% Remove annotation
delete(an);


%~~~~~~~~~~~~~~~~~~~~~~~~
% Create annotation
anString = sprintf('Click on the cusp');
an = annotation('textbox', [.20 .45 .3 .3], 'String', anString, 'FontSize', 12, ...
    'Color', 'r', 'FitBoxToText', 'on', 'LineStyle', 'none', 'FontWeight', 'bold');

[xCusp, yCusp] = ginput(1);

% Show points on the image
plot(xCusp, yCusp, 'rv')

% Remove annotation
delete(an);


%~~~~~~~~~~~~~~~~~~~~~~~~
% Create annotation
% anString = sprintf('Click on the initial and final points of the calibration scale');
% an = annotation('textbox', [.15 .27 .3 .3], 'String', anString, 'FontSize', 12, ...
%     'Color', 'r', 'FitBoxToText', 'on', 'LineStyle', 'none', 'FontWeight', 'bold');
% 
% [xScale, yScale] = ginput(2);
% 
% % Show points on the image
% plot(xScale, yScale, 'r+')
% 
% % Remove annotation
% delete(an);


%~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
% Calculate distance in pixel

% scalePx = sqrt((xScale(1) - xScale(2))^2 + (yScale(1) - yScale(2))^2);
% scaleCm = 1;

scalePx1 = sqrt((xBoundary(1) - xCusp)^2 + (yBoundary(1) - yCusp)^2);
scalePx2 = sqrt((xBoundary(2) - xCusp)^2 + (yBoundary(2) - yCusp)^2);
scalePx  = mean([scalePx1, scalePx2]);
scaleCm  = 5;


% Calibration
Pixel2Meter = scaleCm ./ scalePx * 1e-2;
%~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~

% Create annotation
anString = sprintf('Draw a ROI to crop the image');
an = annotation('textbox', [.45 .65 .3 .3], 'String', anString, 'FontSize', 12, ...
    'Color', 'r', 'FitBoxToText', 'on', 'LineStyle', 'none', 'FontWeight', 'bold');

anString = sprintf('Calibration : %3.2e m/pixel', Pixel2Meter);
anCalibr = annotation('textbox', [.15 .27 .3 .3], 'String', anString, 'FontSize', 12, ...
    'Color', 'r', 'FitBoxToText', 'on', 'LineStyle', 'none', 'FontWeight', 'bold');

ROI = drawrectangle('Label','Select ROI','Color',[1 0 0]);

ROI_coordinates = ROI.Position;

% imageCropped = imcrop(imageFile, ROI.Position);
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

end