%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% This function computes local fitting
%
% Written by: M. Gori, 2020  ~  marcello.gori@jpl.nasa.gov
%
% If using these codes for research or industrial purposes, please cite:
% Gori, M., & Bosi, F. (2022). Deployment and surface accuracy of regularly creased membranes. Extreme Mechanics Letters, 101849. 
% DOI: https://doi.org/10.1016/j.eml.2022.101849
% https://www.sciencedirect.com/science/article/pii/S2352431622001420 
% Published 27 July 2022.
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

function [grad1, grad2, angle1, angle2] = localFit(fitMethod, ...
    x1, y1, x2, y2, nPts, nEnds, nAngleFixedDist)

% Initialize variables
grad1 = nan(size(x1));
grad2 = nan(size(x2));

angle1 = nan(size(x1));
angle2 = nan(size(x2));

for i = 1 : length(x1)

    if i > nPts && i < length(x1) - (nPts-1)
        % Left half of the beam
        fitObj1 = fit(x1(i-nPts : i+nPts), y1(i-nPts : i+nPts), fitMethod);
        % Right half of the beam
        fitObj2 = fit(x2(i-nPts : i+nPts), y2(i-nPts : i+nPts), fitMethod);
        
    elseif i <= nPts
        % Left half of the beam
        fitObj1 = fit(x1(1 : max(nEnds,i)),	y1(1 : max(nEnds,i)),	fitMethod);
        % Right half of the beam
        fitObj2 = fit(x2(1 : max(nEnds,i)),	y2(1 : max(nEnds,i)),   fitMethod);
        
    elseif i >= size(x1) - (nPts-1)
        % Left half of the beam
        fitObj1 = fit(x1(min(i,end-nEnds+1) : end),	y1(min(i,end-nEnds+1) : end),	fitMethod);
        % Right half of the beam
        fitObj2 = fit(x2(min(i,end-nEnds+1) : end),	y2(min(i,end-nEnds+1) : end),	fitMethod);
    end
    
    % Compute gradients in degrees
    grad1(i) = atand(fitObj1.p1);
    grad2(i) = atand(fitObj2.p1);
    
end

% Compute angles
angle1(1)       = (grad1(2)     - grad1(1));
angle1(2:end-1) = (grad1(3:end) - grad1(1:end-2)) / 2;
% angle1(end)     = (grad1(end)   - grad1(end-1));
angle1(end)     = (grad2(nAngleFixedDist) - grad1(end-(nAngleFixedDist-1)));

% angle2(1)       = (grad2(2)     - grad2(1));
angle2(1)       = (grad2(nAngleFixedDist)     - grad1(end-(nAngleFixedDist-1)));
angle2(2:end-1) = (grad2(3:end) - grad2(1:end-2)) / 2;
angle2(end)     = (grad2(end)   - grad2(end-1));

end