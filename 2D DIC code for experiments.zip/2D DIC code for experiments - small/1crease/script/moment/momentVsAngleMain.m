%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% This script reads an image
%
% Written by: M. Gori, 2020  ~  marcello.gori@jpl.nasa.gov
%
% If using these codes for research or industrial purposes, please cite:
% Gori, M., & Bosi, F. (2022). Deployment and surface accuracy of regularly creased membranes. Extreme Mechanics Letters, 101849. 
% DOI: https://doi.org/10.1016/j.eml.2022.101849
% https://www.sciencedirect.com/science/article/pii/S2352431622001420 
% Published 27 July 2022.
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

clc; clear; close all;


scriptsFolder = pwd;
cd ../../test1/


%~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
% IMPORT DATA
dataFolder = pwd;
csvFile = '1creaseT1-15mm.csv';
% [csvFile, dataFolder] = uigetfile('*.csv', 'Select *.csv file to analyze');

% Read csv file
dataTable = readtable([dataFolder '/' csvFile]);

angleAll  = dataTable.Angle_Creast_MaxGrad;
armAll    = dataTable.Arm;
forceAll  = dataTable.Force;
% forceAll  = dataTable.Dev1_ai1_Force;

momentAll = armAll .* forceAll;

% Normalize moment
width = 1.5e-2;   % [m]
nMomentAll = momentAll ./ width;
%~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~


%~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
% Exclude null angle values
index = find(abs(angleAll) > 0);

angle  = 180 - abs(angleAll(index));
angle  = angle - angle(1);

nMoment = nMomentAll(index);



%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Call function to select gray scale via slider
cd(scriptsFolder)
sliderPlotGUI_linearFit(angle, nMoment);


movemeanStencil = 1;
%~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
% CREATE PROMPT WINDOW TO INPUT THE VALUE OF THE PARAMETER

% Inspect the force vs. time plot for filtering
prompt     = {'Points to exclude from end of force data'};
name       = 'Selection';
numLines   = 1;
defaultAns = {'12'};
options.Resize      = 'on';
options.WindowStyle = 'normal';
options.Interpreter = 'tex';
userInput = inputdlg(prompt, name, numLines, defaultAns, options);

% Points to exclude from the end of the force data for filtering
ptsTailExclude = str2double(userInput{1});
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%


%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% FIT LINE TO MOMENT VS ANGLE

fitType = 'poly1';
angleShort  = angle(1:end-ptsTailExclude);
nMomentShort = nMoment(1:end-ptsTailExclude);

fitParam = fit(angleShort, nMomentShort, fitType);

yFit = fitParam.p1*angle + fitParam.p2;
yFitShort = yFit(1:end-ptsTailExclude);

fprintf('\nMoment Slope : %3.2e \n', fitParam.p1);



%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% PLOT FORCE VS. TIME
figHandle = figure('Name', 'Normalized Moment vs. Angle', 'NumberTitle', 'off', 'Color', [1,1,1]);

plot(angleShort, nMomentShort, '.'); hold on
plot(angleShort, yFitShort, 'r-');
% semilogy(angle, nMoment, '.'); hold on
% semilogy(angle, yFit, 'r-');

ax = gca;
ax.FontSize = 13;
ax.LineWidth = 2;

xlabel('Angle [deg]');   ylabel('Moment/Width [N]')
title('Normalized Moment vs. Angle')

legend('Moment Data', 'Linear Fit', 'location', 'NW')
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%


%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% PLOT FORCE VS. TIME
figHandle = figure('Name', 'Normalized Moment vs. Angle', 'NumberTitle', 'off', 'Color', [1,1,1]);

% plot(angleShort, momentShort, '.'); hold on
% plot(angleShort, yFitShort, 'r-');
semilogy(angle, nMoment, '.'); hold on
semilogy(angle, yFit, 'r-');

ax = gca;
ax.FontSize = 13;
ax.LineWidth = 2;

xlabel('Angle [deg]');   ylabel('Moment/Width [N]')
title('Normalized Moment vs. Angle')

legend('Semilog Moment Data', 'Linear Fit', 'location', 'NW')
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%



