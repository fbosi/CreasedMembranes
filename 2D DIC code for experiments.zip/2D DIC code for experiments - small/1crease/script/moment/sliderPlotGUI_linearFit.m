%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% This script creates a GUI slider plot to find the correct F3dB value
% for the Butterworth filter
%
% Copyright :  M. GORI, 2019
% Contact   :  marcello.gori00@gmail.com
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

function [] = sliderPlotGUI_linearFit(x, y)

%~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
% Assign dataObj class values
dataObj.x = x;
dataObj.y = y;

dataObj.ptsTailExclude = 0;
dataObj.linearFit = fit(dataObj.x, dataObj.y, 'poly1');
%~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~


%~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
% Plot different plots according to slider location.
dataObj.fig = figure;
set(dataObj.fig, 'Name', 'GUI slider plot', 'NumberTitle', 'off', 'Color', [1,1,1]);
      
% Plot data and assign plot to update via the slider to dataObject
% plot(x, y, '.'); hold on
plot(x, y, '.'); hold on

% Plot data and assign plot to update via the slider to dataObject
% dataObj.plot = plot(dataObj.x, dataObj.y, 'r.');
dataObj.plot = plot(dataObj.linearFit, dataObj.x, dataObj.y, 'ro');
%~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~


%~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
% Create annotation string
anString = sprintf('Points to exclude  :  %d \nFit Slope  :  % 3.2e', ...
    dataObj.ptsTailExclude, dataObj.linearFit.p1);
    

% Write annotation on the plot
dataObj.an = annotation('textbox', [.4 .6 .3 .3], 'String', anString, 'FontSize', 11, ...
                  'Color', 'r', 'FitBoxToText', 'on', 'LineStyle', 'none', 'FontWeight', 'bold');
              
% Create labels
title('Slide to optimal setting')
xlabel('angle [deg]')
ylabel('moment [Nm]');
%~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~


%~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
% SLIDER APPEARANCE PARAMETER
dataObj.slider = uicontrol('style', 'slide', ...
                 'unit', 'pix', ...
                 'position', [30 5 500 30], ...
                 'min', 0, 'max', 20, 'val', 1, ...
                 'sliderstep', [1/30 1/30],...
                 'callback', {@slider_call, dataObj});
%~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~

end
             

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Callback for the slider
function [] = slider_call(varargin)

% Call handle and data structure
[h, dataObj] = varargin{[1,3]};

% Update value
dataObj.ptsTailExclude = round(h.Value);

% Update dark pixels (brightness < new threshold)
dataObj.x = dataObj.x(1:end-dataObj.ptsTailExclude);
dataObj.y = dataObj.y(1:end-dataObj.ptsTailExclude);
dataObj.linearFit = fit(dataObj.x, dataObj.y, 'poly1');

% Update the plot
set(dataObj.plot(1), 'xdata', dataObj.x, 'ydata', dataObj.y)
set(dataObj.plot(2), 'xdata', dataObj.x, 'ydata', dataObj.linearFit.p1 .* dataObj.x + dataObj.linearFit.p2)

% Update the string
dataObj.an.String = sprintf('Points to exclude  :  %d \nFit Slope  :  % 3.2e', ...
    dataObj.ptsTailExclude, dataObj.linearFit.p1);

% Print the value in the command window
fprintf('Points to exclude  :  %d \n', dataObj.ptsTailExclude);
fprintf('     Moment slope  :  %3.2e \n\n', dataObj.linearFit.p1);

end
