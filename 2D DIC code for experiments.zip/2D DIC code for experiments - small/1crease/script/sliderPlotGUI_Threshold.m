%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% This script creates a GUI slider plot to find the correct F3dB value
% for the Butterworth filter
%
% Copyright :  M. GORI, 2019
% Contact   :  marcello.gori00@gmail.com
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

function [] = sliderPlotGUI_Threshold(imageCropped)

%~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
% Assign dataObj class values
dataObj.x = 0;
dataObj.y = 0;
dataObj.imCrop = imageCropped;
dataObj.brightnessThreshold = 100;

% Find dark pixels (brightness < threshold)
[dataObj.y, dataObj.x] = find(dataObj.imCrop < dataObj.brightnessThreshold);
%~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~


%~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
% Plot different plots according to slider location.
dataObj.fig = figure;
set(dataObj.fig, 'Name', 'GUI slider plot', 'NumberTitle', 'off', 'Color', [1,1,1]);
      
% Plot data and assign plot to update via the slider to dataObject
imshow(dataObj.imCrop); hold on
dataObj.plot = plot(dataObj.x, dataObj.y, '.', 'Color', 'r');

% Reverse image upside down (the origin (0,0) of the plot is in the bottom
% right corner by default, while for imported images is in the top left
% corner)
set(gca, 'YDir','reverse')
%~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~


%~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
% Create annotation string
anString = sprintf('Brightness Threshold [0-255]  :  %d', dataObj.brightnessThreshold);

% Write annotation on the plot
dataObj.an = annotation('textbox', [.55 .63 .3 .3], 'String', anString, 'FontSize', 12, ...
                  'Color', 'r', 'FitBoxToText', 'on', 'LineStyle', 'none', 'FontWeight', 'bold');
              
% Create labels
title('Slide to optimal setting')
xlabel('x [px]')
ylabel('y [px]');
%~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~


%~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
% SLIDER APPEARANCE PARAMETER
dataObj.slider = uicontrol('style', 'slide', ...
                 'unit', 'pix', ...
                 'position', [30 5 500 30], ...
                 'min', 0, 'max', 255, 'val', 120, ...
                 'sliderstep', [1/128 1/128],...
                 'callback', {@slider_call, dataObj});
%~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~

end
             

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Callback for the slider
function [] = slider_call(varargin)

% Call handle and data structure
[h, dataObj] = varargin{[1,3]};

% Update value
dataObj.brightnessThreshold = round(h.Value);

% Update dark pixels (brightness < new threshold)
[dataObj.y, dataObj.x] = find(dataObj.imCrop < dataObj.brightnessThreshold);

% Update the plot
set(dataObj.plot, 'xdata', dataObj.x)
set(dataObj.plot, 'ydata', dataObj.y)

% Update the string
dataObj.an.String = sprintf('Brightness Threshold [0-255]  :  %3d', dataObj.brightnessThreshold);

% Print the value in the command window
fprintf('Brightness Threshold [0-255]  :  %3d \n', dataObj.brightnessThreshold)

end
