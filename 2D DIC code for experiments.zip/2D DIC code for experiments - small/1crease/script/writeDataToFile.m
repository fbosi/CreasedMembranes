%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% This script substitute a line of a csv file
%
% Written by: M. Gori, 2020  ~  marcello.gori@jpl.nasa.gov
%
% If using these codes for research or industrial purposes, please cite:
% Gori, M., & Bosi, F. (2022). Deployment and surface accuracy of regularly creased membranes. Extreme Mechanics Letters, 101849. 
% DOI: https://doi.org/10.1016/j.eml.2022.101849
% https://www.sciencedirect.com/science/article/pii/S2352431622001420 
% Published 27 July 2022.
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

function writeDataToFile(outputFile, csvFolder, fileName, creastAngle, creastAngleMaxGrad, ...
    displ, force, arm, moment, RMSE)

cd(csvFolder)

% Read csv file
dataTable = readtable(outputFile);

% Find row of file of interest
indexFile = find(cellfun('length', regexp(dataTable.Filename_0, fileName)) == 1);

% Write data to the table
dataTable.Angle_Creast(indexFile)         = creastAngle;
dataTable.Angle_Creast_MaxGrad(indexFile) = creastAngleMaxGrad;
dataTable.Displ_Frames_Interp(indexFile)  = displ;
% dataTable.Force(indexFile)                = force;
dataTable.Arm(indexFile)                  = arm;
dataTable.Moment(indexFile)               = moment;
dataTable.RMSE(indexFile)                 = RMSE;

% Save file to output file
writetable(dataTable, outputFile);

end

