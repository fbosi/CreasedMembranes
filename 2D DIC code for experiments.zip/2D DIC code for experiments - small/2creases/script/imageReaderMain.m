%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% This script reads the images and run 2D Digital Image Correlation
%
% Written by: M. Gori, 2020  ~  marcello.gori@jpl.nasa.gov
%
% If using these codes for research or industrial purposes, please cite:
% Gori, M., & Bosi, F. (2022). Deployment and surface accuracy of regularly creased membranes. Extreme Mechanics Letters, 101849. 
% DOI: https://doi.org/10.1016/j.eml.2022.101849
% https://www.sciencedirect.com/science/article/pii/S2352431622001420 
% Published 27 July 2022.
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

clc; clear; close all;


scriptsFolder = pwd;
cd ../test1

%~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
[~, dataFolder] = uigetfile('*.tif', 'Select *.tif file to analyze');
[csvFile, ~] = uigetfile('*.csv', 'Select *.csv file to analyze');

filesList = dir([dataFolder, '/*.tif']);
%~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~


%~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
% Select number of cusps
nCusps = 2;

%~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~

% Select 'user' or 'default' to manually select the brightnessThreshold for
% all frames. Anything else to open a GUI with a drag bar frame by frame.
thresholdInputBy = 'user';
brightnessThreshold = 100;
%~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~



%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% IMPORT INITIAL AND FINAL IMAGES AND DATA

% Initialize the variables
ROIIniFin   = zeros(2,4);   Boundaries  = nan(2,4);
Pixel2Meter = zeros(2,1);   timeIniFin  = zeros(2,1);


count = 0;

for iFile = [1, length(filesList)]
    % Update counter
    count = count + 1;
    
    % Read filename
    fileName = filesList(iFile).name;
    
    % Grab points from plot via mouse click
    cd(scriptsFolder)
    [ROIIniFin(count,:), Boundaries(count,:), Pixel2Meter(count)] = ...
        imagePointsGrab(dataFolder, fileName, Boundaries, nCusps);
    
    % Import initial and final values
    [timeIniFin(count), ~] = csvImportData(csvFile, dataFolder, fileName);
end

% Get calibration scale from undeformed configuration only
% Pixel2Meter = mean(Pixel2Meter);
Pixel2Meter = Pixel2Meter(1);
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%



%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% LOOP TO ANALYZE FILES

% Initialize variables
stopElapsedTimes     = zeros(length(filesList), 1);
displFramesInterp    = zeros(length(filesList), 1);


for iFile = 1 : length(filesList)
    
    % Start timer for loop iteration
    elapsedTime = tic;
    
    % Close figures
    close all;
    
    % Read filename
    fileName = filesList(iFile).name;
    
    
    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    % IMPORT TIME AND FORCE VALUES AND INTERPOLATE THE ROI SIZE
    
    cd(scriptsFolder)
    [time, displ, force] = csvImportData(csvFile, dataFolder, fileName);
    
    %~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
    % Linear interpolation, since the experiment is in displacement control
    % and the displacement increment is linear with time
    
    % Interpolate region of interest in the global (non-cropped) coordinate
    % system
    ROI = interp1(timeIniFin, ROIIniFin, time, 'linear');
    
    % Interpolate boundary points
    % NOTE:
    % Since the time has limited precision, the linear interpolation
    % oscillates around the exact value with errors < +/- 0.45% and
    % negligible error mean.
    BoundaryX = [interp1(timeIniFin, Boundaries(:,1), time, 'linear'), ...
                 interp1(timeIniFin, Boundaries(:,2), time, 'linear')];
    BoundaryY = [interp1(timeIniFin, Boundaries(:,3), time, 'linear'), ...
                 interp1(timeIniFin, Boundaries(:,4), time, 'linear')];
             
    % Boundary1 is the left boundary, Boundary2 is the right boundary in
    % the global (non-cropped) coordinate system
    % Boundary1 = [mean(Boundaries(:,1)), mean(Boundaries(:,2))];
    Boundary1 = [BoundaryX(1); BoundaryY(1)];
    Boundary2 = [BoundaryX(2); BoundaryY(2)];
    
    % boundary1 is the left boundary, boundary2 is the right boundary in
    % the local (cropped) coordinate system
    boundary1 = [Boundary1(1)-ROI(1); Boundary1(2)-ROI(2)];
    boundary2 = [Boundary2(1)-ROI(1); Boundary2(2)-ROI(2)];
    
    % Update displFramesInterp
    displFramesInterp(iFile) = sqrt((Boundary2(1)-Boundary1(1)).^2 + ...
                                    (Boundary2(2)-Boundary1(2)).^2) * Pixel2Meter;
  
    displFramesInterp(iFile) = displFramesInterp(iFile) - displFramesInterp(1);
    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    
    
    
    %~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
    % IMPORT IMAGE DATA
    
    % Create an object for the *.tiff image file
    imageObj = Tiff([dataFolder '/' fileName], 'r');
    
    % Import the image to a matrix. Each entry corresponds to a pixel with the
    % brightness intensity - from 0 to 256 (8-bit)
    imageFile = read(imageObj);
    
    % Close the object
    close(imageObj)
    
    %~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
    % Crop image
    imageCropped = imcrop(imageFile, ROI);
    
    % Call function to select gray scale via slider.
    % Options:
    % - 'default' :  selects a default value of brightness threshold
    % - anything else :  it opens a GUI slider to select the brightness threshold
    cd(scriptsFolder)
    [brightnessThreshold] = callSliderPlotGUI(imageCropped, brightnessThreshold,  thresholdInputBy);
    %~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
    
    
    
    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    % SPLIT PLOT IN TWO HALVES ON EITHER SIDE OF THE CUSP
    
    % Find dark pixels (brightness < threshold)
    [y, x] = find(imageCropped < brightnessThreshold);
    
    
    %~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
    % Sort data
    [x, iSort] = sort(x);
    y = y(iSort);
    
    
    %~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
    % Find duplicates by average y-values (interpolation does not allow
    % duplicate x-values)
    % [x1avg, ~, idx] = unique(x1, 'stable');
    % y1avg = accumarray(idx, y1, [], @mean);
    %
    % [x2avg, ~, idx] = unique(x2, 'stable');
    % y2avg = accumarray(idx, y2, [], @mean);

    [xAvg, ~, idx] = unique(x, 'stable');
    yAvg = accumarray(idx, y, [], @mean);
    
    
    %~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
    % Find distance between cusp and the line connecting the two boundary
    % points
    
    [~, iMax] = min(yAvg);
    
    if iMax == 1
        iMax = 2;
    elseif iMax == length(yAvg)
        iMax = length(yAvg)-1;
    end

    % Find cusp in the global (non-cropped) coordinate system
    Cusp = [ROI(1)+xAvg(iMax); ROI(2)+yAvg(iMax)];
    
    % Compute the arm of the force
    armPx = pointToLine(Cusp, Boundary1, Boundary2);
    arm   = armPx * Pixel2Meter;
    
    % Compute the angular moment
    moment = force * arm;
        
    % Print values in the command window
    fprintf('~~~~~~~~~~~~~~~~~~~~ \n');
    fprintf('%s \n\n', fileName);
    fprintf('M  =  %2.1e N x %2.1e m  =  %2.1e Nm \n\n', force, arm, moment);
    
    
    %~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
    % Revert the y-axis upside down and subtract the boundary point (this
    % is to correctly compute the RMSE)
    % y    = -(y    - max(yAvg));
    % yAvg = -(yAvg - max(yAvg));
    y    = -(y    - boundary1(2));
    yAvg = -(yAvg - boundary1(2));
    
    % Shift the x-axis to the origin
    xAvg = xAvg - xAvg(1);
    
    
    %~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
    % Compute RMSE
    RMSE = sqrt(sum(y.^2) ./ length(y)) * Pixel2Meter;
    
    
    %~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
    % Separate data before and after the max of the y data (supposedly the
    % cusp) to avoid smoothing the cusp out if filter or interpolation is
    % applied
    iPart1 = find(xAvg <= xAvg(iMax));
    iPart2 = find(xAvg >= xAvg(iMax));
    
    x1avg = xAvg(iPart1);     y1avg = yAvg(iPart1);
    x2avg = xAvg(iPart2);     y2avg = yAvg(iPart2);
    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    
    
    
    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    % INTERPOLATE DATA
    
    %~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
    % Interpolate data
    
    % 'linear' (default) | 'nearest' | 'next' | 'previous' | 'pchip' |
    % 'cubic' | 'v5cubic' | 'makima' | 'spline'
    interpMethod = 'linear';
    
    x1Interp = (x1avg(1) : (x1avg(end)-x1avg(1)) / 1e2 : x1avg(end))';
    y1Interp = interp1(x1avg, y1avg, x1Interp, interpMethod);
    
    x2Interp = (x2avg(1) : (x2avg(end)-x2avg(1)) / 1e2 : x2avg(end))';
    y2Interp = interp1(x2avg, y2avg, x2Interp, interpMethod);
    
    x1Interp(end) = x1Interp(end) - 1e-12;
    x2Interp(1)   = x2Interp(1)   + 1e-12;
    
    % Combine data
    xData = [x1Interp; x2Interp];
    yData = [y1Interp; y2Interp];
    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    
    
    
    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    % CURVE FITTING AND COMPUTATION OF THE ANGLE
    
    % Fitting method
    fitMethod = 'poly1';
    
    % Select how many points on each side of the cusp to consider for the fit
    fitNPts = 3;
    
    % Reduced number of points next to the boundaries
    % CAUTION: This value should be smaller or equal than fitNPts
    fitNPtsEnds = 2;
    
    
    nAngleFixedDist = 6;
    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%     % CREATE PROMPT WINDOW TO INPUT THE VALUE OF POINTS TO MOVE OVER
%     
%     % Inspect the gradient plot and exclude the points next to the cusp where
%     % the gradients changes slope
%     prompt     = {'Move away N points on either side of the cusp'};
%     name       = 'Move away N points on either side of the cusp';
%     numLines   = 1;
%     defaultAns = {'5'};
%     options.Resize      = 'on';
%     options.WindowStyle = 'normal';
%     options.Interpreter = 'tex';
%     userInput = inputdlg(prompt, name, numLines, defaultAns, options);
%     
%     nAngleEnds = str2double(userInput{1});
    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    
    
    % Fit data using the function
    cd(scriptsFolder)
    [gradFit1, gradFit2, angleFit1, angleFit2] = localFit(fitMethod, ...
        x1Interp, y1Interp, x2Interp, y2Interp, fitNPts, fitNPtsEnds, nAngleFixedDist);
    
    gradFitData       = [gradFit1; gradFit2];
    gradFitDataSmooth = [smooth(gradFit1); smooth(gradFit2)];
    
    % Compute the angle of the cusp based on:
    % - the diff with the gradient at a fixed distance from the cusp
    angleCuspFixedDist = angleFit1(end);
    % - the max gradient values
    angleCuspMaxGrad = min(gradFitDataSmooth) - max(gradFitDataSmooth);
    
    
    %~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
    % Print to command window the angle computed from the two methods
    fprintf('Crest Angle: \n');
    fprintf('Method Fixed Dist    :  %2.1e deg \n', angleCuspFixedDist);
    fprintf('Method Max Gradient  :  %2.1e deg \n\n', angleCuspMaxGrad);
    %~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
    
    
    % Set the angle at the cusp to be plotted to be computed in either of
    % the two previous methods:
    % - angleCuspFixedDist
    % - angleCuspMaxGrad
    angleFit1(end) = angleCuspMaxGrad;
    angleFit2(1)   = angleCuspMaxGrad;
    

    
    %~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
    % Compute angle in two different ways
    
    % METHOD I
    xDataAngle    = (xData(2:end) + xData(1:end-1)) / 2;
    angleFitDataI = diff(gradFitData);
    % angleFitDataI = diff(gradFitDataSmooth);
    
    % METHOD II
    angleFitDataII = [angleFit1; angleFit2];
    
    % %~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
    % % Gradient in degree
    %
    % % Select how many points on each side of the cusp to consider for the fit
    % gradNPoints = 3;    % default = 1
    %
    % grad1 = atand(gradient(y1Interp, gradNPoints)./gradient(x1Interp, gradNPoints));
    % grad2 = atand(gradient(y2Interp, gradNPoints)./gradient(x2Interp, gradNPoints));
    %
    % % Smooth values
    % grad1Smooth = smooth(grad1);
    % grad2Smooth = smooth(grad2);
    %
    % % grad1Smooth(end)
    %
    % % Combine data
    % gradData       = [grad1; grad2];
    % gradDataSmooth = [grad1Smooth; grad2Smooth];
    %
    % %~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
    % % Compute angle as the difference of the gradients in degree
    % angleData       = diff(gradData);
    % angleDataSmooth = diff(gradDataSmooth);
    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    
    
    
    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    % SAVE DATA TO FILE
    
    cd(scriptsFolder)
    writeDataToFile(csvFile, dataFolder, fileName, angleCuspFixedDist, angleCuspMaxGrad, ...
        displFramesInterp(iFile), force, arm, moment, RMSE)
    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    
    
    
    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    % PLOT DATA
    
    % Plot Deformed Shape
    figDeformed = dataPlot(fileName, scriptsFolder, ...
        x .* Pixel2Meter * 1e3, y .* Pixel2Meter * 1e3, ...
        [x1Interp; x2Interp] .* Pixel2Meter * 1e3, [y1Interp; y2Interp] .* Pixel2Meter * 1e3, ...
        abs(gradFitData), ...
        'Deformed Configuration', {'Raw Data', 'Post-Processed Data'}, 'Deformed', ...
        'x [mm]', 'y [mm]');
    
    % Plot Gradient
    figGradient = dataPlot(fileName, scriptsFolder, ...
        xData .* Pixel2Meter * 1e3, gradFitData, ...
        xData .* Pixel2Meter * 1e3, gradFitDataSmooth, ...
        gradFitData, ...
        'Gradient', {'Unsmoothened', 'Smoothened'}, 'Gradient', ...
        'x [mm]', 'Gradient [deg]');
    
    % Plot Angles computed as the difference of curve fit
    figAngleFit = dataPlot(fileName, scriptsFolder, ...
        xDataAngle.*Pixel2Meter, -angleFitDataI, ...
        xData .* Pixel2Meter * 1e3, -angleFitDataII, ...
        abs(gradFitData), ...
        'Angle via Fit', {'Method I', 'Method II'}, 'Angle', ...
        'x [mm]', 'Angle [deg]');
    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    
    
    %~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
    % Start timer for loop iteration
    stopElapsedTimes(iFile) = toc(elapsedTime);
    remainingTime = (length(filesList)-iFile) * mean(stopElapsedTimes(1:iFile));
    
    fprintf('Loop %3d out of %3d \n', iFile, length(filesList));
    fprintf('Elapsed Time :  %3.2f s  -  Remaining Time :  %2d'' %02.0f s  \n\n', stopElapsedTimes(iFile), floor(remainingTime/60), mod(remainingTime,60));
end



% %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% % CALL SLIDER PLOT
% cd(scriptsFolder)
% sliderPlotGUI_Butterworth(x1, y1, x2, y2)
%
% fprintf('\nPRESS ANY KEY TO CONTINUE... \n')
%
% pause
% close all
%
% %~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
% % CREATE PROMPT WINDOW TO INPUT THE F3dB PARAMETER
% prompt     = {'F3dB value'};
% name       = 'Input F3dB value';
% numLines   = 1;
% defaultAns = {'1e-1'};
% options.Resize      = 'on';
% options.WindowStyle = 'normal';
% options.Interpreter = 'tex';
% userInput = inputdlg(prompt, name, numLines, defaultAns, options);
%
% N = 3;
% F3dB = str2double(userInput{1});
%
% %~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
% % Filter data
% y1Butter = filterButterworth(N, F3dB, y1);
% y2Butter = filterButterworth(N, F3dB, y2);
% %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%



%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
function [figHandle] = dataPlot(fileName, folder, x0, y0, x, y, colorData, ...
    strTitle, strLegend, type, xLabel, yLabel)

figHandle = figure('Name', 'Data Output', 'NumberTitle', 'off', 'Color', [1,1,1]);

plot(x0, y0, 'k.'); hold on
scatter(x, y, [], colorData, 'filled')

if strcmp(type, 'Deformed')
    axis equal
end

ax = gca;
ax.FontSize = 13;
ax.LineWidth = 2;

colormap('parula')
colorbar;

xlabel(xLabel);   ylabel(yLabel)
title(strTitle)

legend(strLegend, 'location', 'NE')

%~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
% Save plots
cd(folder)
cd ../Figs

savefig(figHandle, [fileName(1:end-4) '_' type 'Plot'], 'compact');
print(figHandle,   [fileName(1:end-4) '_' type 'Plot'], '-depsc');

cd(folder)

end



%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
function dist = pointToLine(pt, vertex1, vertex2)

% the 'cross' function only allows 3D vectors
if length(pt) == 2
    pt(end+1)      = 0;
    vertex1(end+1) = 0;
    vertex2(end+1) = 0;
end

% Compute distance of a point to a line
a = vertex1 - vertex2;
b = pt - vertex2;
dist = norm(cross(a, b)) / norm(a);

end




