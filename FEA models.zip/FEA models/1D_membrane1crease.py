# This code was developed with Wolfram Mathematica v.11. Published 27 July 2022.

# If using this code for research or industrial purposes, please cite:
# Gori, M., & Bosi, F. (2022). Deployment and surface accuracy of regularly creased membranes. Extreme Mechanics Letters, 101849. 
# DOI: https://doi.org/10.1016/j.eml.2022.101849
# https://www.sciencedirect.com/science/article/pii/S2352431622001420 

# Comments and corrections:
# Federico Bosi (f.bosi@ucl.ac.uk)
# University College London, Department of Mechanical Engineering

# Please note that the material parameters and geometry do not correspond to those used in the paper above

# load modulus
from part import *
from material import *
from section import *
from assembly import *
from step import *
from interaction import *
from load import *
from mesh import *
from optimization import *
from job import *
from sketch import *
from visualization import *
from connectorBehavior import *
# part
myModel=mdb.Model(name='Model-1')
myModel.ConstrainedSketch(name='__profile__', sheetSize=0.1)
# geometry
# left side
myModel.sketches['__profile__'].Line(point1=(0.0, 0.0), point2=(
    0.035355, 0.035355))
myModel.Part(dimensionality=TWO_D_PLANAR, name='leftpart', type=
    DEFORMABLE_BODY)
myModel.parts['leftpart'].BaseWire(sketch=
    myModel.sketches['__profile__'])
del myModel.sketches['__profile__']
# right side
myModel.ConstrainedSketch(name='__profile__', sheetSize=0.1)
myModel.sketches['__profile__'].Line(point1=(0.035355, 0.035355), 
    point2=(0.0707, 0.0))
myModel.Part(dimensionality=TWO_D_PLANAR, name='rightpart', type=
    DEFORMABLE_BODY)
myModel.parts['rightpart'].BaseWire(sketch=
    myModel.sketches['__profile__'])
del myModel.sketches['__profile__']
# set of parts
myModel.parts['rightpart'].Set(name='ApplyForce', vertices=
    myModel.parts['rightpart'].vertices.getSequenceFromMask((
    '[#2 ]', ), ))
myModel.parts['rightpart'].Set(name='SpringRigthMem', vertices=
    myModel.parts['rightpart'].vertices.getSequenceFromMask((
    '[#1 ]', ), ))
myModel.parts['leftpart'].Set(name='Pinned', vertices=
    myModel.parts['leftpart'].vertices.getSequenceFromMask((
    '[#1 ]', ), ))
myModel.parts['leftpart'].Set(name='LeftSpringMem', vertices=
    myModel.parts['leftpart'].vertices.getSequenceFromMask((
    '[#2 ]', ), ))
# material and section
myModel.Material(name='Mylar')
# Young's modulus and Poisson's ratio
myModel.materials['Mylar'].Elastic(table=((4500000000.0, 0.4), ))
# section
myModel.RectangularProfile(a=0.015, b=0.0001, name='RectSect')
myModel.BeamSection(consistentMassMatrix=False, integration=
    DURING_ANALYSIS, material='Mylar', name='BeamSection', poissonRatio=0.4, 
    profile='RectSect', temperatureVar=LINEAR)
myModel.parts['leftpart'].Set(edges=
    myModel.parts['leftpart'].edges.getSequenceFromMask(('[#1 ]', 
    ), ), name='leftmemset')
# Section assignment
myModel.parts['leftpart'].SectionAssignment(offset=0.0, 
    offsetField='', offsetType=MIDDLE_SURFACE, region=
    myModel.parts['leftpart'].sets['leftmemset'], sectionName=
    'BeamSection', thicknessAssignment=FROM_SECTION)
myModel.parts['rightpart'].Set(edges=
    myModel.parts['rightpart'].edges.getSequenceFromMask((
    '[#1 ]', ), ), name='rightmemset')
myModel.parts['rightpart'].SectionAssignment(offset=0.0, 
    offsetField='', offsetType=MIDDLE_SURFACE, region=
    myModel.parts['rightpart'].sets['rightmemset'], sectionName=
    'BeamSection', thicknessAssignment=FROM_SECTION)
myModel.parts['rightpart'].assignBeamSectionOrientation(method=
    N1_COSINES, n1=(0.0, 0.0, -1.0), region=
    myModel.parts['rightpart'].sets['rightmemset'])
myModel.parts['leftpart'].assignBeamSectionOrientation(method=
    N1_COSINES, n1=(0.0, 0.0, -1.0), region=
    myModel.parts['leftpart'].sets['leftmemset'])
# assembly
myModel.rootAssembly.DatumCsysByDefault(CARTESIAN)
myModel.rootAssembly.Instance(dependent=ON, name='leftpart-1', 
    part=myModel.parts['leftpart'])
myModel.rootAssembly.Instance(dependent=ON, name='rightpart-1', 
    part=myModel.parts['rightpart'])
# step
myModel.StaticStep(initialInc=0.0001, minInc=1e-06, maxInc=0.01, maxNumInc=1000, name=
    'TensionStep', nlgeom=ON, previous='Initial')
# rotational spring through connector
myModel.ConnectorSection(name='RotSpring', rotationalType=
    ROTATION, translationalType=JOIN)
myModel.sections['RotSpring'].setValues(behaviorOptions=(
    ConnectorElasticity(table=((0.00229183, ), ), independentComponents=(), 
    components=(6, )), ))
myModel.sections['RotSpring'].behaviorOptions[0].ConnectorOptions(
    )
myModel.rootAssembly.WirePolyLine(mergeType=IMPRINT, meshable=
    False, points=((
    myModel.rootAssembly.instances['leftpart-1'].vertices[1], 
    myModel.rootAssembly.instances['rightpart-1'].vertices[0]), 
    ))
myModel.rootAssembly.features.changeKey(fromName='Wire-1', 
    toName='Wire-1')
myModel.rootAssembly.Set(edges=
    myModel.rootAssembly.edges.getSequenceFromMask(('[#1 ]', ), )
    , name='Wire-1-Set-1')
myModel.rootAssembly.SectionAssignment(region=
    myModel.rootAssembly.sets['Wire-1-Set-1'], sectionName=
    'RotSpring')
# Boundary conditions
myModel.DisplacementBC(amplitude=UNSET, createStepName=
    'TensionStep', distributionType=UNIFORM, fieldName='', fixed=OFF, 
    localCsys=None, name='pinnedBC', region=
    myModel.rootAssembly.instances['leftpart-1'].sets['Pinned'], 
    u1=0.0, u2=0.0, ur3=UNSET)
myModel.DisplacementBC(amplitude=UNSET, createStepName=
    'TensionStep', distributionType=UNIFORM, fieldName='', fixed=OFF, 
    localCsys=None, name='BCForce', region=
    myModel.rootAssembly.instances['rightpart-1'].sets['ApplyForce']
    , u1=UNSET, u2=0.0, ur3=UNSET)
# Load
myModel.ConcentratedForce(cf1=5.0, createStepName='TensionStep', 
    distributionType=UNIFORM, field='', localCsys=None, name='Force', region=
    myModel.rootAssembly.instances['rightpart-1'].sets['ApplyForce'])
# Mesh
# make instances indipendent
myModel.rootAssembly.makeIndependent(instances=(
    myModel.rootAssembly.instances['leftpart-1'], ))
myModel.rootAssembly.makeIndependent(instances=(
    myModel.rootAssembly.instances['rightpart-1'], ))
# set element type
myModel.rootAssembly.setElementType(elemTypes=(ElemType(
    elemCode=B21, elemLibrary=STANDARD), ), regions=(
    myModel.rootAssembly.instances['rightpart-1'].edges.getSequenceFromMask(
    ('[#1 ]', ), ), ))
# seed assembly
myModel.rootAssembly.seedPartInstance(deviationFactor=0.1, 
    minSizeFactor=0.1, regions=(
    myModel.rootAssembly.instances['leftpart-1'], 
    myModel.rootAssembly.instances['rightpart-1']), size=0.0002)
# generate mesh
myModel.rootAssembly.generateMesh(regions=(
    myModel.rootAssembly.instances['leftpart-1'], 
    myModel.rootAssembly.instances['rightpart-1']))
# create job
mdb.Job(atTime=None, contactPrint=OFF, description='', echoPrint=OFF, 
    explicitPrecision=SINGLE, getMemoryFromAnalysis=True, historyPrint=OFF, 
    memory=90, memoryUnits=PERCENTAGE, model='Model-1', modelPrint=OFF, 
    multiprocessingMode=DEFAULT, name='1CreaseModelExp', nodalOutputPrecision=
    SINGLE, numCpus=6, numDomains=6, numGPUs=0, queue=None, resultsFormat=ODB, 
    scratch='', type=ANALYSIS, userSubroutine='', waitHours=0, waitMinutes=0)
# submit job
mdb.jobs['1CreaseModel'].submit(consistencyChecking=OFF)
